#!/bin/bash
echo "Running basic tests..."
python3 rubikpow_simulator.py
python3 rubikpow_verifier.py
